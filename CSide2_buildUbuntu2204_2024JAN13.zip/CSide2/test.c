#include <stdio.h>

int main() {
    printf("hello world");

    int i = 0;

    return i;
}